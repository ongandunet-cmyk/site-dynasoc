"""
Fix missing French accents in index.html only.
Replaces unaccented words with their proper French equivalents.
"""

import re

# Read file
with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Dictionary of replacements: unaccented -> accented
# Order matters: longer/more specific patterns first to avoid partial matches
replacements = [
    # Title & meta
    ("Transition Numerique Souveraine", "Transition Numérique Souveraine"),
    ("numerique libre, souverain et conforme RGPD", "numérique libre, souverain et conforme RGPD"),
    
    # Hero section
    ("Plaidoyer Numerique", "Plaidoyer Numérique"),
    ("transition numerique", "transition numérique"),
    ("souveraine, ethique", "souveraine, éthique"),
    ("numerique libre, maitrise et conforme", "numérique libre, maîtrisé et conforme"),
    ("Decouvrir comment", "Découvrir comment"),
    ("Donnees en Belgique", "Données en Belgique"),
    
    # Hero cards
    ("Hebergement Local", "Hébergement Local"),
    ("Securite RGPD", "Sécurité RGPD"),
    ("Conformite native", "Conformité native"),
    ("Economies reelles", "Économies réelles"),
    ("Migration reussie", "Migration réussie"),
    
    # Piliers section
    ("Nos 3 piliers d'action", "Nos 3 piliers d'action"),  # already ok
    ("approche complete pour transformer votre relation au numerique", "approche complète pour transformer votre relation au numérique"),
    ("defendons la souverainete numerique aupres des pouvoirs publics", "défendons la souveraineté numérique auprès des pouvoirs publics"),
    ("Des ateliers pratiques pour vous emparer des outils libres", "Des ateliers pratiques pour vous emparer des outils libres"),  # ok
    ("suivi personnalise pour migrer vos outils", "suivi personnalisé pour migrer vos outils"),
    ("Migration assistee", "Migration assistée"),
    ("Coalition d'acteurs", "Coalition d'acteurs"),  # ok
    
    # Problem/Solution section
    ("Le numerique n'est pas neutre", "Le numérique n'est pas neutre"),
    ("Le probleme", "Le problème"),
    ("depend de Google", "dépend de Google"),
    ("vos donnees sont a l'etranger", "vos données sont à l'étranger"),
    ("La solution", "La solution"),  # ok
    ("Il existe une alternative", "Il existe une alternative"),  # ok
    ("heberges localement, conformes RGPD", "hébergés localement, conformes RGPD"),
    ("Pedagogie avant technique", "Pédagogie avant technique"),
    ("on forme vos equipes en francais", "on forme vos équipes en français"),
    ("Comparatif reel", "Comparatif réel"),
    ("d'economies", "d'économies"),
    ("Economies totales", "Économies totales"),
    ("Donnees locales", "Données locales"),
    
    # Stats section
    ("Des resultats concrets", "Des résultats concrets"),
    ("bases sur nos accompagnements reels", "basés sur nos accompagnements réels"),
    ("reduction de couts possible", "réduction de coûts possible"),
    ("conformite RGPD native", "conformité RGPD native"),
    ("licences proprietaires", "licences propriétaires"),
    
    # CTA section
    ("Pret a reprendre le controle", "Prêt à reprendre le contrôle"),
    ("premier echange gratuit", "premier échange gratuit"),
    
    # Footer
    ("souverainete numerique", "souveraineté numérique"),
    ("Confidentialite", "Confidentialité"),
    ("nos actualites et invitations", "nos actualités et invitations"),
    ("droits reserves", "droits réservés"),
    ("passion a Bruxelles", "passion à Bruxelles"),
    ("Communaute", "Communauté"),
    
    # Navigation
    ("En savoir plus", "En savoir plus"),  # ok
    
    # Remaining standalone words that appear in text content
    ("payez plus cher chaque annee", "payez plus cher chaque année"),
]

original = content
count = 0
for old, new in replacements:
    if old != new and old in content:
        content = content.replace(old, new)
        count += 1
        print(f"  Fixed: '{old}' -> '{new}'")

if count > 0:
    with open('index.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"\nDone: {count} corrections applied to index.html")
else:
    print("No corrections needed.")
