import os, glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"

old = '<img src="images/Logo_blanc-Photoroom.png" alt="Dynasoc Logo" style="height: 140px; width: auto; object-fit: contain;">'
new = '<img src="images/Logo_blanc-Photoroom.png" alt="Dynasoc Logo" style="height: 155px; width: auto; object-fit: contain;">'

count = 0
for f in glob.glob(os.path.join(directory, "*.html")):
    with open(f, 'r', encoding='utf-8') as fh: c = fh.read()
    if old in c:
        with open(f, 'w', encoding='utf-8') as fh: fh.write(c.replace(old, new))
        count += 1
print(f"Footer logo matched to header size (155px) in {count} files.")
