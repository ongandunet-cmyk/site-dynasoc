import os
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"

# 1. PME -> Office Team (photo_office.jpg)
pme_file = os.path.join(directory, "pme.html")
with open(pme_file, 'r', encoding='utf-8') as f:
    pme_html = f.read()
# Replace the defis section top with an image
img_tag = '<img src="images/photo_office.jpg" alt="Équipe PME au bureau" class="w-full h-64 object-cover rounded-2xl shadow-xl mb-12">'
pme_html = pme_html.replace('<h2 class="text-3xl font-bold mb-8 text-center fade-up">Vos defis, nos solutions</h2>', 
                            '<h2 class="text-3xl font-bold mb-8 text-center fade-up">Vos defis, nos solutions</h2>\n                ' + img_tag)
with open(pme_file, 'w', encoding='utf-8') as f:
    f.write(pme_html)

# 2. Communaute -> Conference / Meetup (photo_conference.jpg)
communaute_file = os.path.join(directory, "communaute.html")
with open(communaute_file, 'r', encoding='utf-8') as f:
    com_html = f.read()
img_tag2 = '<img src="images/photo_conference.jpg" alt="Événement communautaire Dynasoc" class="w-full h-80 object-cover rounded-2xl shadow-xl mt-8">'
com_html = com_html.replace('<ul class="space-y-6 mb-8">', img_tag2 + '\n                        <ul class="space-y-6 mb-8 mt-8">')
with open(communaute_file, 'w', encoding='utf-8') as f:
    f.write(com_html)

# 3. Ressources -> Books and Laptop (photo_books.jpg)
ressources_file = os.path.join(directory, "ressources.html")
with open(ressources_file, 'r', encoding='utf-8') as f:
    res_html = f.read()
img_tag3 = '<img src="images/photo_books.jpg" alt="Ressources, livres et ordinateur" class="w-full h-72 object-cover rounded-3xl shadow-2xl mt-12 mb-12">'
res_html = res_html.replace('<h2 class="text-2xl font-bold mb-8 fade-up">Guides pratiques</h2>', 
                           img_tag3 + '\n                <h2 class="text-2xl font-bold mb-8 fade-up">Guides pratiques</h2>')
with open(ressources_file, 'w', encoding='utf-8') as f:
    f.write(res_html)

# 4. Actions -> Top-Down Post-Its (photo_planning.jpg)
actions_file = os.path.join(directory, "actions.html")
with open(actions_file, 'r', encoding='utf-8') as f:
    act_html = f.read()
img_tag4 = '<img src="images/photo_planning.jpg" alt="Planification avec Post-its" class="w-full h-72 object-cover rounded-3xl shadow-xl mb-12">'
act_html = act_html.replace('<div class="grid lg:grid-cols-3 gap-8">', img_tag4 + '\n                <div class="grid lg:grid-cols-3 gap-8">')
with open(actions_file, 'w', encoding='utf-8') as f:
    f.write(act_html)

# 5. Index/Home -> Coding (photo_coding.jpg)
index_file = os.path.join(directory, "index.html")
with open(index_file, 'r', encoding='utf-8') as f:
    idx_html = f.read()
img_tag5 = '<img src="images/photo_coding.jpg" alt="Développement de solutions libres" class="w-full h-80 object-cover rounded-3xl shadow-2xl mt-8">'
idx_html = idx_html.replace('<!-- Stats -->', '<!-- Image Accueil -->\n        <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24 fade-up">\n            ' + img_tag5 + '\n        </section>\n\n        <!-- Stats -->')
with open(index_file, 'w', encoding='utf-8') as f:
    f.write(idx_html)

print("Images added to HTML files.")
