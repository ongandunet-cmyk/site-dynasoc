import os, glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"

# Current footer logo: dark version with white bg hack
old_footer = '<img src="images/logo.png" alt="Dynasoc Logo" class="bg-white rounded-xl p-3 shadow-lg" style="height: 80px; width: auto; object-fit: contain;">'

# New footer logo: white version, no bg needed, sized to match header visual (155px with negative margin in header = ~55px visible in flow, so 100px here for equivalent perceived size in footer context)
new_footer = '<img src="images/Logo_blanc.jpeg" alt="Dynasoc Logo" style="height: 100px; width: auto; object-fit: contain;">'

count = 0
for f in glob.glob(os.path.join(directory, "*.html")):
    with open(f, 'r', encoding='utf-8') as fh:
        c = fh.read()
    if old_footer in c:
        c = c.replace(old_footer, new_footer)
        with open(f, 'w', encoding='utf-8') as fh:
            fh.write(c)
        count += 1

print(f"White logo applied to footer in {count} files.")
