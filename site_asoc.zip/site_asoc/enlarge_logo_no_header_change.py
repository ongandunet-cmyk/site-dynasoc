import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

# === HEADER LOGO ===
# Current: 44px, too small. 
# Solution: 90px height with negative margins so the header stays at 72px.
# The fixed h-[72px] won't grow. The logo overflows visually but is centered.
old_header_logo = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 44px; width: auto; object-fit: contain;">'
new_header_logo = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 90px; width: auto; object-fit: contain; margin: -20px 0;">'

# === FOOTER LOGO ===
# Already has white bg which is good. Just make it slightly bigger too.
old_footer_logo = '<img src="images/logo.png" alt="Dynasoc Logo" class="bg-white rounded-xl p-2 shadow-lg" style="height: 60px; width: auto; object-fit: contain;">'
new_footer_logo = '<img src="images/logo.png" alt="Dynasoc Logo" class="bg-white rounded-xl p-3 shadow-lg" style="height: 80px; width: auto; object-fit: contain;">'

count = 0
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False

    if old_footer_logo in content:
        content = content.replace(old_footer_logo, new_footer_logo)
        modified = True

    if old_header_logo in content:
        content = content.replace(old_header_logo, new_header_logo)
        modified = True
    
    if modified:
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        count += 1

print(f"Logo enlarged in {count} files. Header height unchanged.")
