import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

# Current header container
old_header_div = '<div class="flex items-center justify-between min-h-[180px] py-4">'
new_header_div = '<div class="flex items-center justify-between h-[72px]">'

# Current header logo (in header)
old_header_logo = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 160px; width: auto; max-width: 300px; object-fit: contain; margin-left: -10px;">'
new_header_logo = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 44px; width: auto; object-fit: contain;">'

# Current footer logo (has bg-gray-100 class)
old_footer_logo = '<img src="images/logo.png" alt="Dynasoc Logo" class="bg-gray-100 rounded-2xl p-4 shadow-xl" style="height: 160px; width: auto; max-width: 300px; object-fit: contain; margin-left: -10px;">'
new_footer_logo = '<img src="images/logo.png" alt="Dynasoc Logo" class="bg-white rounded-xl p-2 shadow-lg" style="height: 60px; width: auto; object-fit: contain;">'

count = 0
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False

    # Fix header container
    if old_header_div in content:
        content = content.replace(old_header_div, new_header_div)
        modified = True

    # Fix footer logo first (more specific match)
    if old_footer_logo in content:
        content = content.replace(old_footer_logo, new_footer_logo)
        modified = True

    # Fix header logo (less specific match, after footer is already done)
    if old_header_logo in content:
        content = content.replace(old_header_logo, new_header_logo)
        modified = True
    
    if modified:
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        count += 1

print(f"Fixed header and logos in {count} files.")
