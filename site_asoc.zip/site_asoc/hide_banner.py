import os
import glob
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

new_styles = """    <style>
        .goog-te-banner-frame { display: none !important; }
        iframe.goog-te-banner-frame { display: none !important; }
        .VIpgJd-ZVi9od-ORHb-OEVmcd { display: none !important; }
        .VIpgJd-ZVi9od-aZ2wEe-wOHMyf { display: none !important; }
        #goog-gt-tt { display: none !important; }
        body { top: 0px !important; position: static !important; }
        html { top: 0px !important; position: static !important; }
        /* Cacher la translation div */
        #google_translate_element { display: none !important; }
        .goog-tooltip { border: none !important; display: none !important; }
        .goog-tooltip:hover { display: none !important; }
        .goog-text-highlight { background-color: transparent !important; border: none !important; box-shadow: none !important; }
    </style>"""

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()

    # The original style block ends with </style>
    # We find '<style>' followed by '.goog-te-banner-frame' up to '</style>'
    content = re.sub(r"    <style>\s*\.goog-te-banner-frame.*?<\/style>", new_styles, content, flags=re.DOTALL|re.MULTILINE)
    
    with open(file, 'w', encoding='utf-8') as f:
        f.write(content)

print("Styles properly fixed.")
