import os, glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
old = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 130px; width: auto; object-fit: contain; margin: -40px 0;">'
new = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 155px; width: auto; object-fit: contain; margin: -50px 0;">'

count = 0
for f in glob.glob(os.path.join(directory, "*.html")):
    with open(f, 'r', encoding='utf-8') as fh: c = fh.read()
    if old in c:
        with open(f, 'w', encoding='utf-8') as fh: fh.write(c.replace(old, new))
        count += 1
print(f"Logo enlarged to 155px in {count} files.")
