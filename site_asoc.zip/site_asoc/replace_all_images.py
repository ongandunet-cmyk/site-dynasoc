import os
import glob
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"

# ============================================================
# IMAGE MAPPING STRATEGY
# ============================================================
# Page          | Image                                    | Reason
# -------------|------------------------------------------|---------------------------
# index.html   | Meetup_event_with_202604211857.jpeg       | Hero: community power
#              | Laptop_screen_displaying_202604211900.jpeg| Section "numerique non neutre"
# mission.html | People_working ensemble .jpeg             | Teamwork = values
# actions.html | Hands_collaborating_on_202604211858.jpeg  | Collaboration = actions
# ressources   | Desk_with_books_202604211857.jpeg         | Books = resources
# communaute   | Meetup_event_with_202604211857.jpeg       | Community event
# pme.html     | Three_monitors_on_202604221207.jpeg       | Tech workspace = PME
# contact.html | Urban_street_scene_202604221206.jpeg      | Local Bruxelles presence
# ============================================================

img_class_banner = 'class="w-full h-80 object-cover rounded-3xl shadow-2xl"'
img_class_section = 'class="w-full h-72 object-cover rounded-2xl shadow-xl"'

# ========================
# 1. INDEX.HTML
# ========================
f = os.path.join(directory, "index.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

# Replace old unsplash image section with hero-style Meetup image
old_index_img_section = '''        <!-- Image Accueil -->
        <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24 fade-up">
            <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2000&auto=format&fit=crop" alt="Développement de solutions libres" class="w-full h-80 object-cover rounded-3xl shadow-2xl mt-8">
        </section>'''

new_index_img_section = '''        <!-- Image Accueil -->
        <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24 fade-up">
            <div class="relative rounded-3xl overflow-hidden shadow-2xl mt-8">
                <img src="images/Meetup_event_with_202604211857.jpeg" alt="Événement communautaire Dynasoc" class="w-full h-96 object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-gray-900/60 via-transparent to-transparent"></div>
                <div class="absolute bottom-8 left-8 text-white">
                    <p class="text-2xl font-bold" style="font-family: 'Space Grotesk', sans-serif;">La communauté Dynasoc en action</p>
                    <p class="text-gray-200 mt-1">Souveraineté numérique, ensemble.</p>
                </div>
            </div>
        </section>'''

c = c.replace(old_index_img_section, new_index_img_section)

# Add image in the "Problem/Solution" section (after the comparatif card)
old_problem_end = '''                </div>
                </div>
            </div>
        </section>

        <!-- Image Accueil -->'''

# Save index
with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] index.html - Hero image (Meetup event)")

# ========================
# 2. ACTIONS.HTML
# ========================
f = os.path.join(directory, "actions.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

old_actions_img = '<img src="https://images.unsplash.com/photo-1531403009284-440f080d1e12?q=80&w=2000&auto=format&fit=crop" alt="Planification avec Post-its" class="w-full h-72 object-cover rounded-3xl shadow-xl mb-12">'
new_actions_img = '<img src="images/Hands_collaborating_on_202604211858.jpeg" alt="Collaboration et planification strategique" class="w-full h-72 object-cover rounded-3xl shadow-xl mb-12">'

c = c.replace(old_actions_img, new_actions_img)

with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] actions.html - Hands collaborating")

# ========================
# 3. RESSOURCES.HTML
# ========================
f = os.path.join(directory, "ressources.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

old_res_img = '<img src="https://images.unsplash.com/photo-1532012197267-da84d127e765?q=80&w=2000&auto=format&fit=crop" alt="Ressources, livres et ordinateur" class="w-full h-72 object-cover rounded-3xl shadow-2xl mt-12 mb-12">'
new_res_img = '<img src="images/Desk_with_books_202604211857.jpeg" alt="Ressources et documentation Dynasoc" class="w-full h-72 object-cover rounded-3xl shadow-2xl mt-12 mb-12">'

c = c.replace(old_res_img, new_res_img)

with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] ressources.html - Desk with books")

# ========================
# 4. COMMUNAUTE.HTML
# ========================
f = os.path.join(directory, "communaute.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

old_com_img = '<img src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2000&auto=format&fit=crop" alt="Evenement communautaire Dynasoc" class="w-full h-80 object-cover rounded-2xl shadow-xl mt-8">'
new_com_img = '<img src="images/Meetup_event_with_202604211857.jpeg" alt="Evenement communautaire Dynasoc" class="w-full h-80 object-cover rounded-2xl shadow-xl mt-8">'

c = c.replace(old_com_img, new_com_img)

with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] communaute.html - Meetup event")

# ========================
# 5. PME.HTML
# ========================
f = os.path.join(directory, "pme.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

old_pme_img = '<img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2000&auto=format&fit=crop" alt="Equipe PME au bureau" class="w-full h-64 object-cover rounded-2xl shadow-xl mb-12">'
new_pme_img = '<img src="images/Three_monitors_on_202604221207.jpeg" alt="Espace de travail PME numerique" class="w-full h-64 object-cover rounded-2xl shadow-xl mb-12">'

c = c.replace(old_pme_img, new_pme_img)

with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] pme.html - Three monitors workspace")

# ========================
# 6. MISSION.HTML - Add image (currently has none)
# ========================
f = os.path.join(directory, "mission.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

# Add a banner image after the hero title section
old_mission_marker = '''            </div>
        </section>

        <section class="py-16">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold mb-8 text-center fade-up">Nos valeurs fondamentales</h2>'''

new_mission_marker = '''            </div>
        </section>

        <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 fade-up">
            <img src="images/People_working ensemble .jpeg" alt="Equipe Dynasoc au travail" class="w-full h-72 object-cover rounded-3xl shadow-2xl mb-4">
        </section>

        <section class="py-16">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold mb-8 text-center fade-up">Nos valeurs fondamentales</h2>'''

c = c.replace(old_mission_marker, new_mission_marker)

with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] mission.html - People working together")

# ========================
# 7. CONTACT.HTML - Add image (currently has none)
# ========================
f = os.path.join(directory, "contact.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

# Add image before the footer in contact
old_contact_footer = '    <!-- Footer (visible on all pages) -->'
new_contact_section = '''    <!-- Image contextuelle Bruxelles -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 fade-up">
        <div class="relative rounded-3xl overflow-hidden shadow-2xl">
            <img src="images/Urban_street_scene_202604221206.jpeg" alt="Bruxelles - Ancrage local Dynasoc" class="w-full h-64 object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-gray-900/50 to-transparent"></div>
            <div class="absolute bottom-6 left-8 text-white">
                <p class="text-xl font-bold" style="font-family: 'Space Grotesk', sans-serif;">Base a Bruxelles</p>
                <p class="text-gray-200 text-sm">Au coeur de l ecosysteme numerique belge</p>
            </div>
        </div>
    </section>

    <!-- Footer (visible on all pages) -->'''

c = c.replace(old_contact_footer, new_contact_section)

with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] contact.html - Urban street scene (Bruxelles)")

# ========================
# FINAL: Verify no Unsplash URLs remain
# ========================
remaining = 0
for file in glob.glob(os.path.join(directory, "*.html")):
    with open(file, 'r', encoding='utf-8') as fh:
        if 'unsplash.com' in fh.read():
            remaining += 1
            print(f"[WARN] Unsplash URL still found in: {os.path.basename(file)}")

if remaining == 0:
    print("\n[DONE] ALL old images removed. ALL new images placed. Zero Unsplash references remaining.")
else:
    print(f"\n[WARN] {remaining} file(s) still have Unsplash references.")
