import os, glob, re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"

# Fix communaute.html
f = os.path.join(directory, "communaute.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()
c = re.sub(
    r'<img src="https://images\.unsplash\.com/[^"]*"[^>]*>',
    '<img src="images/Meetup_event_with_202604211857.jpeg" alt="Evenement communautaire Dynasoc" class="w-full h-80 object-cover rounded-2xl shadow-xl mt-8">',
    c
)
with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] communaute.html fixed")

# Fix pme.html
f = os.path.join(directory, "pme.html")
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()
c = re.sub(
    r'<img src="https://images\.unsplash\.com/[^"]*"[^>]*>',
    '<img src="images/Three_monitors_on_202604221207.jpeg" alt="Espace de travail PME" class="w-full h-64 object-cover rounded-2xl shadow-xl mb-12">',
    c
)
with open(f, 'w', encoding='utf-8') as fh:
    fh.write(c)
print("[OK] pme.html fixed")

# Final check
for file in glob.glob(os.path.join(directory, "*.html")):
    with open(file, 'r', encoding='utf-8') as fh:
        if 'unsplash.com' in fh.read():
            print(f"[WARN] Still found in {os.path.basename(file)}")
            break
else:
    print("[DONE] Zero Unsplash references remaining.")
