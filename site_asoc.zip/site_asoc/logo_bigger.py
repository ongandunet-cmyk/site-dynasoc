import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

old_header_logo = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 90px; width: auto; object-fit: contain; margin: -20px 0;">'
new_header_logo = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 130px; width: auto; object-fit: contain; margin: -40px 0;">'

count = 0
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if old_header_logo in content:
        content = content.replace(old_header_logo, new_header_logo)
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        count += 1

print(f"Logo enlarged to 130px in {count} files.")
