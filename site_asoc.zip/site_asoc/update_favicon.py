import glob

old = '<link rel="icon" type="image/png" href="images/logo.png">'
new = '<link rel="icon" type="image/jpeg" href="images/favicon.jpeg">'

html_files = glob.glob('*.html')
for f in html_files:
    with open(f, 'r', encoding='utf-8') as fp:
        content = fp.read()
    if old in content:
        content = content.replace(old, new)
        with open(f, 'w', encoding='utf-8') as fp:
            fp.write(content)
        print(f'Updated: {f}')
    else:
        print(f'No change: {f}')
