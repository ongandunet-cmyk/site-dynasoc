import os, glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"

# Footer: replace old white logo with new Photoroom version + bigger
old_footer = '<img src="images/Logo_blanc.jpeg" alt="Dynasoc Logo" style="height: 100px; width: auto; object-fit: contain;">'
new_footer = '<img src="images/Logo_blanc-Photoroom.png" alt="Dynasoc Logo" style="height: 140px; width: auto; object-fit: contain;">'

count = 0
for f in glob.glob(os.path.join(directory, "*.html")):
    with open(f, 'r', encoding='utf-8') as fh:
        c = fh.read()
    if old_footer in c:
        c = c.replace(old_footer, new_footer)
        with open(f, 'w', encoding='utf-8') as fh:
            fh.write(c)
        count += 1

print(f"Footer logo replaced with Photoroom version in {count} files.")
