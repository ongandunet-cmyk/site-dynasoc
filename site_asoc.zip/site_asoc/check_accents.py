"""Check for remaining unaccented French words in index.html"""

with open('index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

missing_patterns = [
    'numerique', 'souverainete', 'securite', 'conformite', 'donnees',
    'hebergement', 'economies', 'reelles', 'reussie', 'ethique',
    'probleme', 'equipes', 'francais', 'evenement', 'resultats',
    'echange', 'actualites', 'communaute', 'confidentialite',
    'proprietaires', 'controle', 'annee', 'couts',
    'assistee', 'personnalise', 'heberges', 'pedagogie',
    'defendons', 'aupres', 'etranger', 'depend', 'decouvrir',
    'reel', 'reduction',
]

found = []
for i, line in enumerate(lines, 1):
    lower = line.lower()
    for pattern in missing_patterns:
        # Find unaccented version but skip if it's inside a URL, attribute, or class name
        if pattern in lower:
            # Simple check: is this in visible text content?
            stripped = line.strip()
            if not stripped.startswith('<!--') and pattern in stripped.lower():
                found.append((i, pattern, stripped[:120]))

if found:
    print(f'Found {len(found)} lines with potentially unaccented words:')
    for linenum, pattern, context in found:
        print(f'  Line {linenum}: "{pattern}" -> {context}')
else:
    print('All French accents look correct!')
