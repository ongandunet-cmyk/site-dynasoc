import os
import glob
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()

    # The footer container is <footer class="bg-gray-900 text-white py-16">
    # We find this container and modify the SVG fill color inside it.
    
    def modify_footer(match):
        footer_block = match.group(0)
        # Replace the specific dark fill of the SVG text with white
        footer_block = footer_block.replace('fill="#1C1C28"', 'fill="#FFFFFF"')
        return footer_block

    pattern = r'<footer[^>]*>[\s\S]*?</footer>'
    content = re.sub(pattern, modify_footer, content)
    
    with open(file, 'w', encoding='utf-8') as f:
        f.write(content)

print("Footer SVG text color changed to white.")
