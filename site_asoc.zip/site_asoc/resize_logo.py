import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

old_img_tag = '<img src="images/logo.png" alt="Dynasoc Logo" class="h-14 w-auto object-contain">'
new_img_tag = '<img src="images/logo.png" alt="Dynasoc Logo" style="width: 146px; height: 44px; object-fit: contain;">'

count = 0
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if old_img_tag in content:
        content = content.replace(old_img_tag, new_img_tag)
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        count += 1

print(f"Resized logo in {count} files.")
