import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

svg_logo = """<svg class="h-10 w-auto" viewBox="0 0 220 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="44" height="44" rx="12" fill="url(#gradLogo)"/>
    <path d="M22 36C18 36 14 38 10 40M22 36V42M22 36C26 36 30 38 34 40M22 28V36M22 28L15 20M15 20H10M15 20V12M22 28L29 20M29 20H34M29 20V12M22 28V16M22 16L18 12M22 16L26 12M15 20L11 16M29 20L33 16" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="10" cy="40" r="1" fill="white"/><circle cx="22" cy="42" r="1" fill="white"/><circle cx="34" cy="40" r="1" fill="white"/>
    <circle cx="10" cy="20" r="1.5" fill="white"/><circle cx="15" cy="12" r="1.5" fill="white"/>
    <circle cx="34" cy="20" r="1.5" fill="white"/><circle cx="29" cy="12" r="1.5" fill="white"/>
    <circle cx="18" cy="12" r="1.5" fill="white"/><circle cx="26" cy="12" r="1.5" fill="white"/>
    <circle cx="11" cy="16" r="1.5" fill="white"/><circle cx="33" cy="16" r="1.5" fill="white"/>
    <defs><linearGradient id="gradLogo" x1="0" y1="0" x2="44" y2="44" gradientUnits="userSpaceOnUse"><stop stop-color="#00D4FF"/><stop offset="1" stop-color="#0055FF"/></linearGradient></defs>
    <text x="56" y="32" font-family="'Inter', sans-serif" font-weight="800" font-size="28" fill="#1C1C28" letter-spacing="-0.5">Dynasoc<tspan dy="-12" font-size="12" font-weight="700">®</tspan></text>
</svg>"""

target_str = '<img src="images/logo.png" alt="Dynasoc" class="h-12 w-auto object-contain mix-blend-multiply">'

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    content = content.replace(target_str, svg_logo)
    
    with open(file, 'w', encoding='utf-8') as f:
        f.write(content)

print("SVG logo injected.")
