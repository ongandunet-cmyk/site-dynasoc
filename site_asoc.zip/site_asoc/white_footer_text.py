import os
import glob
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()

    # The block we want to target is the footer button.
    # It has 'gap-3 mb-6 bg-transparent'.
    # We want to add text-white to its span.
    
    def add_white_text(match):
        block = match.group(0)
        # Add text-white to the specific span
        block = block.replace('class="text-xl font-bold"', 'class="text-xl font-bold text-white"')
        return block

    # We match from the start of the button opening tag to the closing button tag
    pattern = r'<button[^>]*gap-3 mb-6 bg-transparent[^>]*>[\s\S]*?</button>'
    
    content = re.sub(pattern, add_white_text, content)
    
    with open(file, 'w', encoding='utf-8') as f:
        f.write(content)

print("Footer logo text changed to white.")
