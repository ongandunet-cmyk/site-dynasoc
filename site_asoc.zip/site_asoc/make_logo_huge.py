import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

old_img_tag = '<img src="images/logo.png" alt="Dynasoc Logo" style="width: 146px; height: 44px; object-fit: contain;">'
new_img_tag = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 85px; width: auto; object-fit: contain; margin-left: -10px;">'

old_header_class = '<div class="flex items-center justify-between h-[72px]">'
new_header_class = '<div class="flex items-center justify-between min-h-[90px] py-2">'

count = 0
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    if old_img_tag in content:
        content = content.replace(old_img_tag, new_img_tag)
        modified = True
        
    if old_header_class in content:
        content = content.replace(old_header_class, new_header_class)
        modified = True
        
    if modified:
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        count += 1

print(f"Resized logo and header in {count} files.")
