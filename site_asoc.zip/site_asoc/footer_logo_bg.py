import os
import glob
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

original_img = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 160px; width: auto; max-width: 300px; object-fit: contain; margin-left: -10px;">'
new_img = '<img src="images/logo.png" alt="Dynasoc Logo" class="bg-gray-100 rounded-2xl p-4 shadow-xl" style="height: 160px; width: auto; max-width: 300px; object-fit: contain; margin-left: -10px;">'

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()

    def modify_footer(match):
        footer_block = match.group(0)
        footer_block = footer_block.replace(original_img, new_img)
        return footer_block

    pattern = r'<footer[^>]*>[\s\S]*?</footer>'
    content = re.sub(pattern, modify_footer, content)
    
    with open(file, 'w', encoding='utf-8') as f:
        f.write(content)

print("Footer image background updated.")
