import os
import glob

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

# The tag currently looks like:
# <img src="images/logo.png" alt="Dynasoc Logo" style="height: 85px; width: auto; object-fit: contain; margin-left: -10px;">
target_img = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 85px; width: auto; object-fit: contain; margin-left: -10px;">'
new_img = '<img src="images/logo.png" alt="Dynasoc Logo" style="height: 160px; width: auto; max-width: 300px; object-fit: contain; margin-left: -10px;">'

target_header = '<div class="flex items-center justify-between min-h-[90px] py-2">'
new_header = '<div class="flex items-center justify-between min-h-[180px] py-4">'

count = 0
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    if target_img in content:
        content = content.replace(target_img, new_img)
        modified = True
    
    if target_header in content:
        content = content.replace(target_header, new_header)
        modified = True
        
    if modified:
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        count += 1

print(f"Made logo EXTREMELY big in {count} files.")
