import os
import glob
import re

directory = r"C:\Users\achaa\.gemini\antigravity\scratch\site_asoc"
files = glob.glob(os.path.join(directory, "*.html"))

# We want to replace the exact SVG block and the span next to it inside the header and footer
# The structure is:
# <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
#     ...
# </svg>
# <span class="text-xl font-bold" style="font-family: 'Space Grotesk', sans-serif;">Dynasoc<span class="text-xs align-top">®</span></span>

new_logo_html = '<img src="images/logo.png" alt="Dynasoc" class="h-12 w-auto object-contain mix-blend-multiply">'

pattern = r'<svg width="44" height="44" viewBox="0 0 44 44" fill="none">.*?</svg>\s*<span class="text-xl font-bold" style="font-family: \'Space Grotesk\', sans-serif;">Dynasoc<span class="text-xs align-top">®</span></span>'

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    content = re.sub(pattern, new_logo_html, content, flags=re.DOTALL)
    
    with open(file, 'w', encoding='utf-8') as f:
        f.write(content)

print("Logo replaced in all files.")
