@echo off
echo Lancement du serveur local pour le fonctionnement de la traduction...
echo Vous pouvez fermer cette fenetre noire quand vous avez fini de naviguer.
start "" http://localhost:8000
python -m http.server 8000
